"""
Web host for Memory Match: serves the game and the shared high score board.

Build the browser version first (requires: pip install pygbag):

    py -m pygbag --build .

Then start this server and open http://localhost:8000 in a browser:

    py server.py            # port 8000
    py server.py 8080       # any other port

The static game files are served from build/web. High scores are stored in
leaderboard.json next to this script and shared by every connected player.

API (used by the game itself, same origin, so no CORS issues):
    GET /api/scores                                          -> the whole board
    GET /api/scores?name=..&difficulty=..&moves=..&time_ms=.. -> add + the board

Only the Python standard library is needed.
"""

import json
import sys
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "build" / "web"
LEADERBOARD_PATH = BASE_DIR / "leaderboard.json"

DIFFICULTIES = ("Easy", "Medium", "Hard")
MAX_HIGHSCORES = 10
MAX_NAME_LENGTH = 12
MAX_MOVES = 100_000        # sanity limits against junk submissions
MAX_TIME_MS = 3_600_000    # one hour

_lock = threading.Lock()   # leaderboard file access


def empty_board():
    """One empty list per difficulty."""
    return {label: [] for label in DIFFICULTIES}


def normalize_board(data):
    """Keep only known difficulties and well-formed entries, sorted and capped."""
    board = empty_board()
    if not isinstance(data, dict):
        return board
    for label in board:
        for entry in data.get(label, []):
            try:
                board[label].append({
                    "name": str(entry["name"]),
                    "moves": int(entry["moves"]),
                    "time_ms": int(entry["time_ms"]),
                })
            except (KeyError, TypeError, ValueError):
                continue  # skip malformed entries
        board[label].sort(key=lambda e: (e["moves"], e["time_ms"]))
        del board[label][MAX_HIGHSCORES:]
    return board


def load_board():
    """Read leaderboard.json; start fresh if it is missing or corrupt."""
    try:
        data = json.loads(LEADERBOARD_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = None
    return normalize_board(data)


def add_entry(name, difficulty, moves, time_ms):
    """Insert an entry, keep the best ones, save, and return the whole board."""
    with _lock:
        board = load_board()
        entries = board[difficulty]
        entries.append({"name": name, "moves": moves, "time_ms": time_ms})
        entries.sort(key=lambda e: (e["moves"], e["time_ms"]))
        del entries[MAX_HIGHSCORES:]
        LEADERBOARD_PATH.write_text(json.dumps(board, indent=2), encoding="utf-8")
        return board


def parse_submission(query):
    """Validate query string parameters; return (name, difficulty, moves,
    time_ms) or None if anything is missing or out of range."""
    params = parse_qs(query)
    try:
        name = params.get("name", [""])[0].strip() or "Player"
        difficulty = params["difficulty"][0]
        moves = int(params["moves"][0])
        time_ms = int(params["time_ms"][0])
    except (KeyError, IndexError, ValueError):
        return None
    if difficulty not in DIFFICULTIES:
        return None
    if not 1 <= moves <= MAX_MOVES or not 0 <= time_ms <= MAX_TIME_MS:
        return None
    return name[:MAX_NAME_LENGTH], difficulty, moves, time_ms


class Handler(SimpleHTTPRequestHandler):
    """Static files from build/web plus the /api/scores endpoints."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_DIR), **kwargs)

    def _send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        # Allow the API to be used even when the game is hosted elsewhere.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/scores":
            super().do_GET()  # static game file
            return
        if parsed.query:
            submission = parse_submission(parsed.query)
            if submission is None:
                self._send_json({"error": "invalid submission"}, status=400)
                return
            board = add_entry(*submission)
        else:
            with _lock:
                board = load_board()
        self._send_json(board)


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    if not WEB_DIR.is_dir():
        print(f"warning: {WEB_DIR} not found - build the game first with:")
        print("    py -m pygbag --build .")
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"Serving Memory Match on http://localhost:{port} (Ctrl+C to stop)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
